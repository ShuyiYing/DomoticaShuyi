
const char* temperatura_topic = "casa/sensores/temperatura4";
const char* humidade_topic = "casa/sensores/humidade4";
const char* depuracion_topic = "depuracion4";  
const char* rele_topic = "casa/actuadores/rele4";  
